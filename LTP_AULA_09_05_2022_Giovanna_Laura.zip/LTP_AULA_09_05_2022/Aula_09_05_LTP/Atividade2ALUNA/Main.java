public class Main {
    public static void main(String[] args) {
        //private ArrayList<Livraria> livraria2;

        // Definindo o tipo da classe
        Author author2 = new Author("Nome 1", "autor1@gmail.com", "f");
        Book book2 = new Book("Livro 1", 25.00, "Autor 1");
        System.out.println(Author + Book);

        // Criando um item livraria
        ItemLivraria ItemLivraria1 = new ItemLivraria(author2);
        ItemLivraria book = new ItemLivraria(Book);
        
        // Criando um objeto da classe Book
        Livro livro2 = new Livro();

        // Criando um objeto da classe Author
        Autor autor2 = new Autor();

        //Usando os métodos da classe Book + mostrando "Book"
        System.out.println("Dados do livro: " + book2);

        //Classe author
        System.out.println("Dados do autor: " + author2);


        
        
    }
}
